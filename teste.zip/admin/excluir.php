
<?php
require_once dirname(__DIR__) . '/config.php';

// Verifica se o administrador está autenticado
auth();

// Aceita somente requisições POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: painel.php');
    exit;
}

// Verifica proteção CSRF
verify_token();

// Recebe e valida o ID da inscrição
$id = filter_input(INPUT_POST, 'id_inscricao', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header('Location: painel.php?erro=1');
    exit;
}

try {
    $pdo = db();

    // Exclui somente a inscrição selecionada
    $q = $pdo->prepare(
        'DELETE FROM inscricoes WHERE id_inscricao = ?'
    );

    $q->execute([$id]);

    if ($q->rowCount() > 0) {
        header('Location: painel.php?excluida=1');
    } else {
        header('Location: painel.php?erro=1');
    }

    exit;

} catch (Throwable $ex) {
    error_log($ex->getMessage());

    header('Location: painel.php?erro=1');
    exit;
}
