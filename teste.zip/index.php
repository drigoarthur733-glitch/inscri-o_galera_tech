<?php require_once __DIR__ . "/config.php"; ?>
<!doctype html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Galera Tech | Inscrição</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/style.css">
  <style>
    :root {
      --azul: #0796c7;
      --azul-escuro: #0875a5;
      --azul-claro: #eaf7fc;
      --amarelo: #f5c400;
      --branco: #ffffff;
    }

    body {
      background-color: #DCE8ED;
      min-height: 100vh;
    }

    /* Cabeçalho */
    .cabecalho {
      background: linear-gradient(135deg, var(--azul-escuro), var(--azul));
      color: white;
      padding: 35px 0;
      border-bottom: 5px solid var(--amarelo);
    }

    /* Cartões das etapas */
    .secao {
      border: 1px solid #d5eaf3;
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 25px;
      background: var(--branco);
      box-shadow: 0 4px 15px rgba(0, 80, 120, 0.10);
    }

    .secao .card-header {
      background: var(--azul-claro);
      color: var(--azul-escuro);
      padding: 18px;
      border-bottom: 2px solid var(--amarelo);
    }

    /* Numeração das etapas */
    .numero {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      margin-right: 10px;
      border-radius: 50%;
      background: var(--amarelo);
      color: #173b50;
      font-weight: bold;
    }

    /* Campos para preencher */
    .form-control,
    .form-select {
      border: 1.5px solid #b9dce9;
      border-radius: 8px;
      padding: 11px;
      background-color: white;
      color: #173b50;
      transition: 0.2s;
    }

    .form-control:focus,
    .form-select:focus {
      border-color: var(--amarelo);
      box-shadow: 0 0 0 0.22rem rgba(245, 196, 0, 0.22);
      background-color: #fffef7;
    }

    /* Textos dos campos */
    .form-label {
      color: var(--azul-escuro);
      font-weight: 600;
    }

    .obrigatorio {
      color: #d99e00;
      font-weight: bold;
    }

    /* Botão de inscrição */
    .btn-primary {
      background-color: var(--azul);
      border-color: var(--azul);
      color: white;
      font-weight: bold;
      border-radius: 8px;
      padding: 11px 22px;
    }

    .btn-primary:hover {
      background-color: var(--azul-escuro);
      border-color: var(--amarelo);
      color: white;
    }

    /* Botão limpar */
    .btn-outline-secondary {
      border: 2px solid var(--azul);
      color: var(--azul-escuro);
      border-radius: 8px;
    }

    .btn-outline-secondary:hover {
      background-color: var(--amarelo);
      border-color: var(--amarelo);
      color: #173b50;
    }

    /* Caixas de seleção */
    .form-check-input:checked {
      background-color: var(--azul);
      border-color: var(--azul);
    }

    .form-check-input:focus {
      border-color: var(--amarelo);
      box-shadow: 0 0 0 0.2rem rgba(245, 196, 0, 0.25);
    }

    .form-check-label {
      color: #24485b;
    }

    /* Links */
    a {
      color: var(--azul-escuro);
      font-weight: 600;
    }

    a:hover {
      color: #bd9200;
    }

    /* Rodapé */
    footer {
      color: var(--azul-escuro);
      font-weight: 600;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 8px;
      padding: 15px;
    }

    /* FUNDO DOS CARTÕES */
    .secao {
      border: 2px solid #0796c7;
      border-radius: 15px;
      box-shadow: 0 8px 25px rgba(0, 70, 120, 0.22);
      background: #ffffff;
    }

    /* TÍTULOS DAS SEÇÕES */
    .secao .card-header {
      background: linear-gradient(90deg, #0875a5, #079fd0);
      color: #ffffff;
      border-bottom: 5px solid #f5c400;
      padding: 20px;
    }

    .secao .card-header h2 {
      color: #ffffff;
      font-weight: 800;
    }

    /* NÚMEROS DAS ETAPAS */
    .numero {
      background: #ffcc00;
      color: #075477;
      border: 2px solid #ffffff;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
      width: 36px;
      height: 36px;
    }

    /* CAMPOS DE PREENCHIMENTO */
    .form-control,
    .form-select {
      border: 2px solid #9bcfe3;
      background-color: #f7fcff;
      font-weight: 500;
      min-height: 45px;
    }

    .form-control:hover,
    .form-select:hover {
      border-color: #0796c7;
    }

    .form-control:focus,
    .form-select:focus {
      border: 2px solid #f5c400;
      background-color: #ffffff;
      box-shadow: 0 0 0 4px rgba(245, 196, 0, 0.25);
    }

    /* NOMES DOS CAMPOS */
    .form-label {
      color: #075477;
      font-weight: 800;
    }

    /* BOTÃO PRINCIPAL */
    .btn-primary {
      background: linear-gradient(135deg, #0785b8, #005b91);
      border: 2px solid #f5c400;
      color: #ffffff;
      font-weight: 800;
      padding: 13px 28px;
      border-radius: 10px;
      box-shadow: 0 5px 12px rgba(0, 80, 130, 0.25);
      transition: 0.3s;
    }

    .btn-primary:hover {
      background: #f5c400;
      border-color: #e0ad00;
      color: #06496b;
      transform: translateY(-2px);
    }

    /* BOTÃO LIMPAR */
    .btn-outline-secondary {
      border: 2px solid #0785b8;
      color: #075477;
      font-weight: 700;
    }

    /* DESTAQUE DOS CAMPOS OBRIGATÓRIOS */
    .obrigatorio {
      color: #e5a900;
      font-size: 17px;
      font-weight: 900;
    }

    /* CAIXAS INFORMATIVAS */
    .alert-info,
    .alert-primary {
      border-left: 6px solid #f5c400 !important;
      background: #e5f6fc;
      color: #075477;
      border-radius: 10px;
    }

    /* CAIXAS DE CONFIRMAÇÃO */
    .form-check {
      background: #f0f9fd;
      border: 1px solid #b8deed;
      border-left: 4px solid #0796c7;
      border-radius: 8px;
      padding: 14px 14px 14px 38px;
    }

    .form-check-input:checked {
      background-color: #0785b8;
      border-color: #f5c400;
    }

    /* RODAPÉ */
    footer {
      border-top: 4px solid #f5c400;
      color: #075477;
      font-weight: 800;
    }
  </style>
</head>

<body>
  <header class="cabecalho">


    <img src="img/galera-tech.png"
      alt="Mascote Galera Tech"
      class="mascote-galera">

    <div class="container" style="max-width:950px">

      <div class="small text-uppercase fw-bold opacity-75 mb-2">
        Programa de estudos • Inscrição
      </div>

      <h1 class="h2 fw-bold mb-2">
        Galera Tech — Formulário de Inscrição
      </h1>

      <p class="mb-0 opacity-75">
        Preencha seus dados para realizar sua inscrição.
      </p>


    </div>
  </header>


  <main class="container py-4" style="max-width:950px">

    <div class="alert alert-light border" role="note"><strong>Sobre o Galera Tech:</strong> capacitação gratuita em tecnologia, com aulas presenciais à tarde, <strong>exclusiva para estudantes que estejam cursando o Ensino Médio em escolas públicas</strong>. Antes de se inscrever, leia as condições do programa e confirme sua ciência na seção final.</div>
    <div id="mensagemSucesso" class="alert alert-success d-none" role="status" tabindex="-1"></div>
    <form id="formInscricao" method="post" action="salvar_inscricao.php" novalidate><input type="hidden" name="csrf" value="<?= e(token()) ?>">
      <div class="mb-4 p-3 bg-white rounded shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <strong id="textoProgresso">Etapa 1 de 5</strong>
          <span id="nomeEtapa" class="text-secondary small">Dados pessoais</span>
        </div>

        <div class="progress" style="height: 12px;">
          <div
            id="barraProgresso"
            class="progress-bar"
            role="progressbar"
            style="width: 20%;"
            aria-valuenow="20"
            aria-valuemin="0"
            aria-valuemax="100">
          </div>
        </div>
      </div>

      <section class="card secao">
        <div class="card-header">
          <h2 class="h5 mb-0"><span class="numero">1</span>Dados pessoais do estudante e Aviso de Privacidade</h2>
        </div>
        <p class="small mt-2 mb-0">
          <a href="aviso-privacidade.html">
            <h5>Acesse o Aviso de Privacidade e Tratamento de Dados</h5>
          </a>
        </p>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-md-8"><label for="nome" class="form-label">Nome completo <span class="obrigatorio">*</span></label><input class="form-control" id="nome" name="nome" autocomplete="name" maxlength="150" required>
              <div class="invalid-feedback">Informe o nome completo.</div>
            </div>
            <div class="col-md-4"><label for="nascimento" class="form-label">Data de nascimento <span class="obrigatorio">*</span></label><input type="date" class="form-control" id="nascimento" name="data_nascimento" required>
              <div class="invalid-feedback">Informe uma data de nascimento válida.</div>
            </div>
            <div class="col-md-6"><label for="cpf" class="form-label">CPF <span class="obrigatorio">*</span></label><input class="form-control" id="cpf" name="cpf" inputmode="numeric" placeholder="000.000.000-00" maxlength="14" required>
              <div class="invalid-feedback">Informe um CPF válido.</div>
            </div>
            <div class="col-md-6">
              <label for="rg" class="form-label">
                RG / Documento de identidade
                <span class="obrigatorio">*</span>
              </label>

              <input type="text"
                class="form-control"
                id="rg"
                name="rg"
                placeholder="00.000.000-0"
                maxlength="12"
                inputmode="numeric"
                required>

              <div class="invalid-feedback">
                Informe o documento de identidade.
              </div>
            </div>

            <div class="col-md-4"><label for="sexo" class="form-label">Sexo <span class="obrigatorio">*</span></label><select class="form-select" id="sexo" name="sexo" required>
                <option value="">Selecione</option>
                <option>Masculino</option>
                <option>Feminino</option>
                <option>Não desejo informar</option>
              </select>
              <div class="invalid-feedback">Selecione uma opção.</div>
            </div>
            <div class="col-md-4"><label for="email" class="form-label">E-mail <span class="obrigatorio">*</span></label><input type="email" class="form-control" id="email" name="email" maxlength="150" autocomplete="email" required>
              <div class="invalid-feedback">Informe um e-mail válido.</div>
            </div>
            <div class="col-md-4"><label for="telefone" class="form-label">WhatsApp do estudante (com DDD) <span class="obrigatorio">*</span></label><input type="tel" class="form-control" id="telefone" name="telefone" placeholder="(17) 99999-9999" maxlength="15" inputmode="numeric" required>
              <div class="invalid-feedback">Informe um celular com DDD (11 dígitos).</div>
            </div>

          </div>
          <div class="d-flex justify-content-end mt-4">
            <button type="button" class="btn btn-primary proxima-etapa">
              Próxima etapa →
            </button>
          </div>
        </div>
      </section>

      <section class="card secao">
        <div class="card-header">
          <h2 class="h5 mb-0"><span class="numero">2</span>Residência e endereço</h2>
        </div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-12"><label for="resideRioPreto" class="form-label">Você reside em São José do Rio Preto? <span class="obrigatorio">*</span></label><select id="resideRioPreto" name="reside_rio_preto" class="form-select" required>
                <option value="">Selecione</option>
                <option value="sim">Sim</option>
                <option value="nao">Não</option>
              </select>
              <div class="invalid-feedback">Informe se reside em São José do Rio Preto.</div>
            </div>
            <div class="col-md-3"><label for="cep" class="form-label">CEP <span class="obrigatorio">*</span></label><input class="form-control" id="cep" name="cep" placeholder="00000-000" maxlength="9" inputmode="numeric" required>
              <div class="invalid-feedback">Informe um CEP com 8 dígitos.</div>
            </div>
            <div class="col-md-7"><label for="logradouro" class="form-label">Logradouro <span class="obrigatorio">*</span></label><input class="form-control" id="logradouro" name="logradouro" maxlength="150" placeholder="Rua, avenida..." required>
              <div class="invalid-feedback">Informe o logradouro.</div>
            </div>
            <div class="col-md-2"><label for="numero" class="form-label">Número <span class="obrigatorio">*</span></label><input class="form-control" id="numero" name="numero" maxlength="15" required>
              <div class="invalid-feedback">Informe o número ou S/N.</div>
            </div>
            <div class="col-md-5"><label for="complemento" class="form-label">Complemento</label><input class="form-control" id="complemento" name="complemento" maxlength="100"></div>
            <div class="col-md-4"><label for="bairro" class="form-label">Bairro <span class="obrigatorio">*</span></label><input class="form-control" id="bairro" name="bairro" maxlength="100" required>
              <div class="invalid-feedback">Informe o bairro.</div>
            </div>
            <div class="col-md-5"><label for="cidade" class="form-label">Cidade <span class="obrigatorio">*</span></label><input class="form-control" id="cidade" name="cidade" maxlength="100" required>
              <div class="invalid-feedback">Informe a cidade.</div>
            </div>
            <div class="col-md-3"><label for="estado" class="form-label">Estado (UF) <span class="obrigatorio">*</span></label><select class="form-select" id="estado" name="estado" required>
                <option value="">Selecione</option>
                <option value="AC">Acre (AC)</option>
                <option value="AL">Alagoas (AL)</option>
                <option value="AP">Amapá (AP)</option>
                <option value="AM">Amazonas (AM)</option>
                <option value="BA">Bahia (BA)</option>
                <option value="CE">Ceará (CE)</option>
                <option value="DF">Distrito Federal (DF)</option>
                <option value="ES">Espírito Santo (ES)</option>
                <option value="GO">Goiás (GO)</option>
                <option value="MA">Maranhão (MA)</option>
                <option value="MT">Mato Grosso (MT)</option>
                <option value="MS">Mato Grosso do Sul (MS)</option>
                <option value="MG">Minas Gerais (MG)</option>
                <option value="PA">Pará (PA)</option>
                <option value="PB">Paraíba (PB)</option>
                <option value="PR">Paraná (PR)</option>
                <option value="PE">Pernambuco (PE)</option>
                <option value="PI">Piauí (PI)</option>
                <option value="RJ">Rio de Janeiro (RJ)</option>
                <option value="RN">Rio Grande do Norte (RN)</option>
                <option value="RS">Rio Grande do Sul (RS)</option>
                <option value="RO">Rondônia (RO)</option>
                <option value="RR">Roraima (RR)</option>
                <option value="SC">Santa Catarina (SC)</option>
                <option value="SP">São Paulo (SP)</option>
                <option value="SE">Sergipe (SE)</option>
                <option value="TO">Tocantins (TO)</option>
              </select>
              <div class="invalid-feedback">Selecione o estado.</div>
            </div>
          </div>
          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary etapa-anterior">
              ← Voltar
            </button>

            <button type="button" class="btn btn-primary proxima-etapa">
              Próxima etapa →
            </button>
          </div>
        </div>
      </section>

      <section class="card secao">
        <div class="card-header">
          <h2 class="h5 mb-0"><span class="numero">3</span>Informações escolares</h2>
        </div>
        <div class="card-body">
          <div class="row g-3">
            <div class="col-md-8"><label for="escola" class="form-label">Nome completo da escola de origem <span class="obrigatorio">*</span></label><input type="text" class="form-control" id="escola" name="nome_escola" maxlength="150" placeholder="Digite o nome da escola" required>
              <div class="invalid-feedback">Informe o nome da escola.</div>
            </div>
            <div class="col-md-6"><label for="serie" class="form-label">Série / ano escolar <span class="obrigatorio">*</span></label><input type="text" class="form-control" id="serie" name="serie_escolar" placeholder="Ex.: 2º ano do Ensino Médio" maxlength="80" required>
              <div class="invalid-feedback">Informe a série ou ano escolar.</div>
            </div>
            <div class="col-md-6"><label for="origemDivulgacao" class="form-label">Por onde conheceu o Galera Tech? <span class="obrigatorio">*</span></label><select class="form-select" id="origemDivulgacao" name="origem_divulgacao" required>
                <option value="">Selecione</option>
                <option>Instagram / Redes sociais</option>
                <option>Escola (Diretoria / Professores)</option>
                <option>Amigos ou familiares</option>
                <option>Anúncio no rádio ou TV</option>
                <option>Outros</option>
              </select>
              <div class="invalid-feedback">Selecione como conheceu o projeto.</div>
            </div>
          </div>
          <div class="alert alert-primary mt-3 mb-0" role="note" id="informacaoTransporte"><strong>Transporte e deslocamento:</strong> o auxílio-transporte (cartão Circular Santa Luzia), quando disponibilizado pelo programa, é destinado aos estudantes matriculados em escolas do município de São José do Rio Preto. Para residentes de outras cidades, os custos e a logística de deslocamento às atividades presenciais ficam sob responsabilidade do candidato ou responsável.</div>
          <p class="small text-secondary mt-3 mb-0">O Galera Tech ocorre à tarde. O ano e o semestre da inscrição serão definidos pelo sistema, não pelo candidato.</p>
        </div>
        <div class="d-flex justify-content-between mt-4">
          <button type="button" class="btn btn-outline-secondary etapa-anterior">
            ← Voltar
          </button>

          <button type="button" class="btn btn-primary proxima-etapa">
            Próxima etapa →
          </button>
        </div>
      </section>

      <section class="card secao">
        <div class="card-header">
          <h2 class="h5 mb-0"><span class="numero">4</span>Dados do responsável</h2>
        </div>
        <div class="card-body">
          <p class="small text-secondary" id="ajudaResponsavel">Nome, WhatsApp e parentesco são obrigatórios para estudantes menores de 18 anos e opcionais para maiores.</p>
          <div class="row g-3">
            <div class="col-md-7"><label for="responsavelNome" class="form-label">Nome completo do responsável <span class="obrigatorio" id="asteriscoResponsavel">*</span></label><input class="form-control responsavel" id="responsavelNome" name="responsavel_nome" maxlength="150" autocomplete="off">
              <div class="invalid-feedback">Informe o nome do responsável.</div>
            </div>
            <div class="col-md-5"><label for="parentesco" class="form-label">Grau de parentesco com o estudante <span class="obrigatorio" id="asteriscoParentesco">*</span></label><select class="form-select responsavel" id="parentesco" name="parentesco">
                <option value="">Selecione o grau de parentesco</option>
                <option value="Mãe">Mãe</option>
                <option value="Pai">Pai</option>
                <option value="Tutor(a) / Responsável legal">Tutor(a) / Responsável legal</option>
                <option value="Outro">Outro</option>
              </select>
              <div class="invalid-feedback">Selecione o parentesco.</div>
            </div>
            <div class="col-md-5"><label for="responsavelTelefone" class="form-label">WhatsApp do responsável (com DDD) <span class="obrigatorio" id="asteriscoTelefoneResponsavel">*</span></label><input type="tel" class="form-control responsavel" id="responsavelTelefone" name="responsavel_telefone" maxlength="15" inputmode="numeric" placeholder="(17) 99999-9999">
              <div class="invalid-feedback">Informe um WhatsApp com DDD (11 dígitos).</div>
            </div>

            <div class="d-flex justify-content-between mt-4">
              <button type="button" class="btn btn-outline-secondary etapa-anterior">
                ← Voltar
              </button>

              <button type="button" class="btn btn-primary proxima-etapa">
                Próxima etapa →
              </button>
            </div>
          </div>
        </div>
      </section>

      <section class="card secao">
        <div class="card-header">
          <h2 class="h5 mb-0"><span class="numero">5</span>Declarações e confirmação</h2>
        </div>
        <div class="card-body">
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="cienciaPrograma" name="ciencia_programa" required><label class="form-check-label" for="cienciaPrograma"><strong>Li e compreendi as condições do Galera Tech:</strong> a capacitação é gratuita, presencial no período da tarde e <strong>exclusiva para estudantes do Ensino Médio de escolas públicas</strong>. <span class="obrigatorio">*</span></label>
            <div class="invalid-feedback">Confirme que leu e compreendeu as condições de participação.</div>
          </div>
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="cienciaTransporte" name="ciencia_transporte" required><label class="form-check-label" for="cienciaTransporte"><strong>Li e compreendi as condições de transporte e deslocamento</strong> descritas acima, incluindo as regras do auxílio-transporte e a responsabilidade pelos custos e pela logística de deslocamento quando aplicável. <span class="obrigatorio">*</span></label>
            <div class="invalid-feedback">Confirme a ciência das condições de transporte e deslocamento.</div>
          </div>
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="veracidade" name="declarou_veracidade" required><label class="form-check-label" for="veracidade">Declaro que as informações fornecidas são verdadeiras. <span class="obrigatorio">*</span></label>
            <div class="invalid-feedback">É necessário confirmar esta declaração.</div>
          </div>
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="privacidade" name="ciencia_privacidade" required><label class="form-check-label" for="privacidade">Declaro que li e estou ciente do referente à inscrição. <span class="obrigatorio">*</span></label>
            <div class="invalid-feedback">É necessário registrar a ciência do aviso de privacidade.</div>
          </div>
          <p class="small text-secondary">* Campos obrigatórios. O aviso de privacidade está disponível no link acima; o texto é uma minuta que deverá ser revisada pela organização antes de receber dados reais.</p>

          <div class="d-flex justify-content-between mt-4">
            <button type="button" class="btn btn-outline-secondary etapa-anterior">
              ← Voltar
            </button>

            <button type="submit" class="btn btn-primary px-5">
              Enviar inscrição
            </button>
          </div>
        </div>
      </section>
    </form>
    <footer class="text-center py-3">
      Galera Tech
    </footer>
  </main>
  <script src="assets/validacoes.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const campoRG = document.getElementById('rg');

      if (!campoRG) return;

      campoRG.addEventListener('input', function() {
        let valor = this.value.replace(/\D/g, '').substring(0, 9);

        if (valor.length > 8) {
          valor = valor.replace(/^(\d{2})(\d{3})(\d{3})(\d)$/, '$1.$2.$3-$4');
        } else if (valor.length > 5) {
          valor = valor.replace(/^(\d{2})(\d{3})(\d+)$/, '$1.$2.$3');
        } else if (valor.length > 2) {
          valor = valor.replace(/^(\d{2})(\d+)$/, '$1.$2');
        }

        this.value = valor;
      });
    });
  </script>


  </script>
</body>

</html>